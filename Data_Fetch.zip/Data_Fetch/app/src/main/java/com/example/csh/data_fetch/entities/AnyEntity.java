package com.example.csh.data_fetch.entities;



public class AnyEntity {

    private int id;
    private Object name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }
}
