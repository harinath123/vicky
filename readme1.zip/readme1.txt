wget http://bit.ly/h

http://bit.ly/121017cal-calculator
http://bit.ly/121017call-calling
http://bit.ly/121017data-datafetch
http://bit.ly/121017invent-inventory
http://bit.ly/121017web-web
http://bit.ly/121017chat-chat
http://bit.ly/121017music-music
http://bit.ly/121017music1-music
http://bit.ly/121017broadcast
http://bit.ly/121017email-email
http://bit.ly/121017inv1-inv1
http://bit.ly/121017sms-sms
http://bit.ly/121017dbinva-dbinv1
http://bit.ly/121017dbinv2-dbinv2
http://bit.ly/121017dblog1-dblog1
http://bit.ly/121017dblog2-dblog2