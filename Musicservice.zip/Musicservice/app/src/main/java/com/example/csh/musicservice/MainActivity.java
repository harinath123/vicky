package com.example.csh.musicservice;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = null;
    public MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        player = MediaPlayer.create(this, R.raw.hii);
        player.setLooping(true);
        player.setVolume(100,100);
    }

    public void startplaying(View view){
        player.start();
        TextView status = (TextView) findViewById(R.id.status_text);
        status.setText("playing");
    }

    public void stopplaying(View view){
        player.stop();
        TextView status = (TextView) findViewById(R.id.status_text);
        status.setText("stopped");
    }

    public void resumeplaying(View view){
        player.start();
        TextView status = (TextView) findViewById(R.id.status_text);
        status.setText("resumed playing");
    }

    public void rewindplaying(View view){
        player.seekTo(0);
        player.stop();
        TextView status = (TextView) findViewById(R.id.status_text);
        status.setText("rewinded and stopped");
    }
}
