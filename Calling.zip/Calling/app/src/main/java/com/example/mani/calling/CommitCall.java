package com.example.mani.calling;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.Prediction;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

@SuppressWarnings("ResourceType")
public class CommitCall extends Activity implements GestureOverlayView.OnGesturePerformedListener {
    private static int SPLASH_TIME_OUT = 3000;
    GestureLibrary glibrary;
    SQLiteDatabase mydb;
    String num ;
    String name ;
    TextToSpeech t1;

    class C00481 implements TextToSpeech.OnInitListener {
        C00481() {
        }

        public void onInit(int status) {
            if (status != -1) {
                CommitCall.this.t1.setLanguage(new Locale("en", "IN"));
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.commitcall);
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
      //  Toast.makeText(getApplicationContext(), "hai", Toast.LENGTH_LONG);
        v.vibrate(500);

        this.glibrary = GestureLibraries.fromFile("/sdcard/gestures");
        if (!this.glibrary.load()) {
            finish();
        }
        this.t1 = new TextToSpeech(getApplicationContext(), new C00481());
        ((GestureOverlayView) findViewById(R.id.gOverlay)).addOnGesturePerformedListener(this);
        Button data = (Button) findViewById(R.id.home);
        data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CommitCall.this, GestureBuilderActivity.class);
                intent.putExtra("val", "stop");
                CommitCall.this.startActivity(intent);
                CommitCall.this.finish();
            }
        });

    }
    @SuppressWarnings("deprecation")
    public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
        ArrayList<Prediction> predictions = this.glibrary.recognize(gesture);
        if (predictions.size() <= 0 || ((Prediction) predictions.get(0)).score <= 1.0d) {
            Toast.makeText(getApplicationContext(), "Wrong Pattern", 1).show();
            this.t1.speak("Wrong Pattern", 0, null);
            return;
        }
        phonecall(((Prediction) predictions.get(0)).name);
    }
    @SuppressWarnings("deprecation")
    public void phonecall(String text) {
        try {

            this.mydb = openOrCreateDatabase(Database.DBNAME, Context.MODE_PRIVATE, null);

            Cursor c = this.mydb.rawQuery("select * from TABLES where NAME='"+text+"' ", null);
             // Toast.makeText(getApplicationContext(),"num " ,1).show();
             //   if(c.isNull(1)){
             //     Toast.makeText(getApplicationContext(),"numnull " ,1).show();}


            if (c.moveToFirst()) {
                this.num = c.getString(2);
                this.name=  c.getString(1);
                Toast.makeText(getApplicationContext(),"num " +num  ,1).show();
                Thread.sleep(1000);
                Thread.sleep(1000);
            }
            Toast.makeText(getApplicationContext(), "Calling " + name, 1).show();
            Thread.sleep(1000);
            this.t1.speak("calling" + name, 0, null);
            Thread.sleep(1000);
            Thread.sleep(1000);

            Intent callIntent = new Intent("android.intent.action.CALL");
            callIntent.setData(Uri.parse("tel: " + CommitCall.this.num));
            CommitCall.this.startActivity(callIntent);
            CommitCall.this.finish();
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Saving error", 0).show();
        }


    }
}
