package com.example.mani.calling;


import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
public class Database extends Activity
{
    Context context=this;
    SQLiteDatabase mydb;
    public static final String DBNAME="CONTACTS.db";
    public static final String TABLE="TABLES";

    TextView tname;
    TextView tno;
    EditText ename;
    EditText eno;
    Button save;
    Button show;
    String sname,sno;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);
        tname=(TextView)findViewById(R.id.textView2);
        tname.setTextColor(Color.BLACK);
        tno=(TextView)findViewById(R.id.textView3);
        tno.setTextColor(Color.BLACK);
        ename=(EditText)findViewById(R.id.editText1);
        eno=(EditText)findViewById(R.id.editText2);

        createTable();

        save=(Button)findViewById(R.id.button1);
        save.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                sname=ename.getText().toString();
                sno=eno.getText().toString();
                if(sname.equals("")||sno.equals(""))
                {
                    AlertDialog.Builder box=new AlertDialog.Builder(context);
                    box.setTitle("Alert!!!");
                    box.setMessage("Contact details should not be empty!!!");
                    box.setPositiveButton("OK", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.cancel();
                        }
                    });
                    box.show();
                }
                else
                {
                    final AlertDialog.Builder box=new AlertDialog.Builder(context);
                    box.setTitle("Alert!!!");
                    box.setMessage("Are you sure???");
                    box.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            saveContact(sname,sno);
                            Toast.makeText(getApplicationContext(), "Contact saved successfully!!!", Toast.LENGTH_SHORT).show();

                            AlertDialog.Builder ges=new AlertDialog.Builder(context);
                            ges.setTitle("Draw a pattern for "+sname+"!!");
                            ges.setPositiveButton("Draw Pattern", new DialogInterface.OnClickListener()
                            {

                                @Override
                                public void onClick(DialogInterface dialog, int which)
                                {
                                    Intent intent=new Intent(context,CreateGestureActivity.class);

                                    Bundle bundle = new Bundle();
                                    bundle.putString("value", sname);

                                    intent.putExtras(bundle);
                                    startActivity(intent);
                                }
                            });
                            ges.show();
                        }

                    }).setNegativeButton("No", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.cancel();
                        }
                    });
                    box.show();

                }
            }
        });

    }

    private void createTable()
    {
        try
        {
            mydb=openOrCreateDatabase(DBNAME, Context.MODE_PRIVATE, null);
            mydb.execSQL("CREATE TABLE IF  NOT EXISTS TABLES (ID INTEGER PRIMARY KEY, NAME TEXT NOT NULL UNIQUE, MOB_NO TEXT NOT NULL UNIQUE);");
            Toast.makeText(getApplicationContext(),"TABLE CREATED ",Toast.LENGTH_LONG).show();
            File backupDB = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Database.db");
            File currentDB = context.getDatabasePath("CONTACTS.db");
            if (currentDB.exists()) {
                FileChannel src = new FileInputStream(currentDB).getChannel();
                FileChannel dst = new FileOutputStream(backupDB).getChannel();
                dst.transferFrom(src, 0, src.size());
                src.close();
                dst.close();
            }
            Thread.sleep(1000);
            mydb.close();
        }
        catch(Exception e)
        {
            Toast.makeText(getApplicationContext(), "Table error", Toast.LENGTH_SHORT).show();
        }

    }

    private void saveContact(String name, String no)
    {
        try
        {
            mydb=openOrCreateDatabase(DBNAME, Context.MODE_PRIVATE, null);
            mydb.execSQL("INSERT INTO TABLES (NAME,MOB_NO) VALUES ('" + name + "','" + no + "')");
            Toast.makeText(getApplicationContext(),"INSERTED "+name+"number"+no,Toast.LENGTH_LONG).show();
            Thread.sleep(1000);
            mydb.close();
        }
        catch(Exception e)
        {
            Toast.makeText(getApplicationContext(), "Error while saving contact", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(context,Database.class);
            startActivity(intent);

        }
    }

}
